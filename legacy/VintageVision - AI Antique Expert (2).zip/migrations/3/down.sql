
DROP INDEX idx_search_history_user_id;
DROP INDEX idx_api_usage_user_id;
DROP INDEX idx_analytics_events_timestamp;
DROP INDEX idx_user_subscriptions_user_id;

DROP TABLE search_history;
DROP TABLE api_usage;
DROP TABLE analytics_events;
DROP TABLE user_subscriptions;
