
DROP TABLE marketplace_links;
DROP TABLE user_wishlists;
DROP TABLE analysis_feedback;
DROP TABLE user_preferences;
ALTER TABLE item_analyses DROP COLUMN styling_suggestions;
