
DROP INDEX idx_collection_items_analysis_id;
DROP INDEX idx_collection_items_user_id;
DROP TABLE collection_items;
DROP TABLE item_analyses;
