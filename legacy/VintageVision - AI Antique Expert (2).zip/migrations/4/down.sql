
DROP INDEX idx_performance_metrics_timestamp;
DROP INDEX idx_performance_metrics_name;
DROP INDEX idx_error_logs_timestamp;

DROP TABLE performance_metrics;
DROP TABLE error_logs;
